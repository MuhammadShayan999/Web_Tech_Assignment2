<?php
require_once '../Templates/Header.php';
require_once '../Public/Countries.php';

$results_data = null;
$search_query = ""; // Use 'search_query' to match your HTML form's input name

if (isset($_POST['submit_search'])) {
    // 1. Corrected: Use 'search_query' to access the POST data
    $search_query = $_POST['search_query']; 

    // 2. Instantiate and search
    $country = new Countries();
    $results_data = $country->search($search_query); // Assuming you added the search() method

    // The display logic (iterating through $results_data) is now moved into the HTML section below
}

?>

<!-- Below here is where you add your HTML structure to display the results nicely -->
<div class="container my-3">
    <h3>Search Results <?php echo htmlspecialchars($search_query); ?></h3>
    <div class="table-responsive">
        <table class="table table-primary">
            <thead>
                <tr>
                    <th scope="col">Country ID</th>
                    <th scope="col">Country Name</th>
                    <th scope="col">Region ID</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($results_data && $results_data->num_rows > 0) {
                    // Loop through the results and display them in table rows
                    while ($row = $results_data->fetch_assoc()) {
                        echo '
                        <tr class="">
                            <td>' . htmlspecialchars($row['country_id']) . '</td>
                            <td>' . htmlspecialchars($row['country_name']) . '</td>
                            <td>' . htmlspecialchars($row['region_id']) . '</td>
                        </tr>';
                    }
                } elseif (isset($_POST['submit_search'])) {
                    // Display this if no results were found for the submitted search
                    echo '<tr class=""><td colspan="3">No results found for "'.$search_query.'".</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php 
// require_once '../Templates/Footer.php'; 
?>
